import { useEffect } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

export const useScrollAnimations = () => {
  useEffect(() => {
    // Smooth scrolling for the entire page
    gsap.registerPlugin(ScrollTrigger);

    // Background scroll-follow animation
    const handleBackgroundScroll = () => {
      const scrolled = window.pageYOffset;
      const parallax1 = scrolled * 0.2;
      const parallax2 = scrolled * 0.1;

      gsap.to('.parallax-bg-1', {
        y: parallax1,
        duration: 0.1,
        ease: "none"
      });

      gsap.to('.parallax-bg-2', {
        y: parallax2,
        duration: 0.1,
        ease: "none"
      });
    };

    window.addEventListener('scroll', handleBackgroundScroll);

    // Cleanup
    return () => {
      window.removeEventListener('scroll', handleBackgroundScroll);
      ScrollTrigger.getAll().forEach(trigger => trigger.kill());
    };
  }, []);
};