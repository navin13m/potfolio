import React, { useState, useEffect, useRef } from 'react';
import { gsap } from 'gsap';

const ThemeToggle = () => {
  const [isDark, setIsDark] = useState(true);
  const moonRef = useRef(null);

  useEffect(() => {
    const savedTheme = localStorage.getItem('theme');
    if (savedTheme) {
      setIsDark(savedTheme === 'dark');
      document.documentElement.classList.toggle('dark', savedTheme === 'dark');
    } else {
      document.documentElement.classList.add('dark');
    }
  }, []);

  useEffect(() => {
    const moon = moonRef.current;
    if (!moon) return;

    if (isDark) {
      // Dark theme - glowing moon
      gsap.to(moon, {
        filter: 'brightness(1.2) contrast(1.1)',
        boxShadow: '0 0 40px rgba(255,255,255,0.6), 0 0 80px rgba(255,255,255,0.3)',
        duration: 0.8,
        ease: "power2.out"
      });
    } else {
      // Light theme - darker moon silhouette
      gsap.to(moon, {
        filter: 'brightness(0.7) contrast(1.3)',
        boxShadow: '0 0 20px rgba(0,0,0,0.2)',
        duration: 0.8,
        ease: "power2.out"
      });
    }
  }, [isDark]);

  const toggleTheme = () => {
    const newTheme = !isDark;
    setIsDark(newTheme);
    document.documentElement.classList.toggle('dark', newTheme);
    localStorage.setItem('theme', newTheme ? 'dark' : 'light');
    
    // Animate the toggle
    gsap.to(moonRef.current, {
      scale: 0.9,
      duration: 0.2,
      yoyo: true,
      repeat: 1,
      ease: "power2.inOut"
    });
  };

  return (
    <button
      onClick={toggleTheme}
      className="fixed top-6 right-6 md:top-8 md:right-8 z-50 w-12 h-12 md:w-16 md:h-16 rounded-full transition-all duration-500 cursor-hover"
      aria-label="Toggle theme"
    >
      <div 
        ref={moonRef}
        className="w-full h-full rounded-full relative overflow-hidden transition-all duration-500"
        style={{
          backgroundImage: 'url(https://images.pexels.com/photos/1118873/pexels-photo-1118873.jpeg?auto=compress&cs=tinysrgb&w=200)',
          backgroundSize: 'cover',
          backgroundPosition: 'center'
        }}
      >
        {/* Moon surface details */}
        <div className="absolute top-2 left-2 w-1 h-1 md:w-2 md:h-2 bg-gray-600/40 rounded-full"></div>
        <div className="absolute bottom-2 right-2 w-1 h-1 md:w-1.5 md:h-1.5 bg-gray-600/30 rounded-full"></div>
        <div className="absolute top-3 right-3 w-0.5 h-0.5 md:w-1 md:h-1 bg-gray-600/50 rounded-full"></div>
      </div>
    </button>
  );
};

export default ThemeToggle;