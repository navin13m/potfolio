import React, { useEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { ChevronDown, Code, Terminal, Cpu, Zap, Database, Layers } from 'lucide-react';
import RedBug from './RedBug';
import data from '../data.json';

const Hero = () => {
  const heroRef = useRef(null);
  const textRef = useRef(null);
  const buttonRef = useRef(null);
  const iconsRef = useRef([]);

  useEffect(() => {
    const tl = gsap.timeline();
    
    tl.from(textRef.current.children, {
      y: 80,
      opacity: 0,
      duration: 1.2,
      stagger: 0.2,
      ease: "power3.out"
    })
    .from(buttonRef.current, {
      y: 40,
      opacity: 0,
      duration: 0.8,
      ease: "power3.out"
    }, "-=0.4");

    // Animate coding icons
    iconsRef.current.forEach((icon, index) => {
      if (icon) {
        gsap.fromTo(icon, 
          { scale: 0, rotation: -90, opacity: 0 },
          {
            scale: 1,
            rotation: 0,
            opacity: 0.6,
            duration: 1,
            delay: 1.2 + index * 0.15,
            ease: "back.out(1.7)"
          }
        );

        // Floating animation
        gsap.to(icon, {
          y: Math.sin(index * 0.5) * 15,
          x: Math.cos(index * 0.3) * 10,
          duration: 4 + index * 0.5,
          repeat: -1,
          yoyo: true,
          ease: "power2.inOut"
        });
      }
    });

    // Background parallax effect
    const handleScroll = () => {
      const scrolled = window.pageYOffset;
      const parallax = scrolled * 0.2;
      
      gsap.to(heroRef.current, {
        transform: `translateY(${parallax}px)`,
        duration: 0.1,
        ease: "none"
      });
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToAbout = () => {
    document.getElementById('about').scrollIntoView({ behavior: 'smooth' });
  };

  const codingIcons = [
    { Icon: Code, position: 'top-20 md:top-32 left-4 md:left-20', color: 'text-blue-500 dark:text-blue-400' },
    { Icon: Terminal, position: 'top-32 md:top-48 left-12 md:left-40', color: 'text-green-500 dark:text-green-400' },
    { Icon: Database, position: 'top-44 md:top-64 left-20 md:left-60', color: 'text-purple-500 dark:text-purple-400' },
    { Icon: Layers, position: 'bottom-32 md:bottom-48 left-8 md:left-32', color: 'text-orange-500 dark:text-orange-400' },
    { Icon: Cpu, position: 'bottom-20 md:bottom-32 left-16 md:left-52', color: 'text-pink-500 dark:text-pink-400' },
    { Icon: Zap, position: 'bottom-44 md:bottom-64 left-24 md:left-72', color: 'text-yellow-500 dark:text-yellow-400' }
  ];

  return (
    <section 
      id="home"
      ref={heroRef}
      className="min-h-screen flex items-center justify-center relative overflow-hidden"
      role="banner"
    >
      {/* Enhanced background for light theme */}
      <div className="absolute inset-0 opacity-100 dark:opacity-0 transition-opacity duration-500">
        <div className="absolute inset-0 bg-gradient-to-br from-blue-100/50 via-purple-100/30 to-pink-100/40"></div>
        <div className="absolute top-1/4 left-1/4 w-64 h-64 bg-gradient-radial from-blue-300/20 via-purple-300/15 to-transparent rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute bottom-1/4 right-1/3 w-80 h-80 bg-gradient-radial from-purple-300/20 via-pink-300/15 to-transparent rounded-full blur-3xl animate-pulse delay-1000"></div>
      </div>

      {/* Red Bug in Computer - positioned with more space */}
      <div className="absolute top-1/4 right-8 md:right-1/4 z-30">
        <RedBug />
      </div>
      
      {/* Coding Icons - only on home screen, responsive positioning */}
      {codingIcons.map(({ Icon, position, color }, index) => (
        <div
          key={index}
          ref={el => iconsRef.current[index] = el}
          className={`absolute ${position} opacity-60 dark:opacity-80 transition-opacity duration-500 hidden md:block`}
        >
          <div className="relative">
            <Icon className={`w-4 h-4 md:w-6 md:h-6 ${color} drop-shadow-lg filter transition-all duration-300`} />
            <div className={`absolute inset-0 ${color.replace('text-', 'bg-').replace('-500', '-500/10').replace('-400', '-400/10')} rounded-full blur-lg scale-150`}></div>
          </div>
        </div>
      ))}
      
      <div className="text-center px-4 md:px-6 lg:px-12 max-w-6xl mx-auto relative z-20">
        <div ref={textRef}>
          <h2 className="text-2xl sm:text-3xl md:text-4xl lg:text-5xl font-light text-gray-800 dark:text-gray-200 mb-4 transition-colors duration-500">
            Hi, I'm
          </h2>
          
          <h1 className="text-4xl sm:text-5xl md:text-6xl lg:text-8xl font-bold text-gray-900 dark:text-white mb-6 leading-tight transition-colors duration-500">
            <span className="bg-gradient-to-r from-red-500 via-red-600 to-red-700 dark:from-red-400 dark:via-red-500 dark:to-red-600 bg-clip-text text-transparent drop-shadow-sm">
              Naveen
            </span>
          </h1>
          
          <p className="text-xl sm:text-2xl md:text-3xl lg:text-4xl text-gray-800 dark:text-gray-100 mb-8 max-w-4xl mx-auto leading-relaxed font-medium transition-colors duration-500">
            Frontend Developer
          </p>
          
          <p className="text-base md:text-lg lg:text-xl text-gray-700 dark:text-gray-200 mb-12 max-w-3xl mx-auto leading-relaxed transition-colors duration-500">
            Creating beautiful, functional, and user-friendly web experiences with cutting-edge technology
          </p>
        </div>
        
        <div ref={buttonRef} className="flex flex-col sm:flex-row gap-4 md:gap-6 justify-center items-center">
          <button
            onClick={scrollToAbout}
            className="cursor-hover group relative px-6 md:px-10 py-3 md:py-4 bg-gradient-to-r from-red-500 to-red-600 dark:from-red-600 dark:to-red-700 text-white font-semibold rounded-full hover:shadow-xl hover:shadow-red-500/30 dark:hover:shadow-red-500/50 transform hover:scale-105 transition-all duration-300 overflow-hidden"
            aria-label="View my work"
          >
            <span className="relative z-10 flex items-center text-sm md:text-base">
              See My Work
              <ChevronDown className="ml-2 h-4 w-4 md:h-5 md:w-5 group-hover:animate-bounce" />
            </span>
            <div className="absolute inset-0 bg-gradient-to-r from-red-600 to-red-700 dark:from-red-700 dark:to-red-800 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
          </button>
          
          <div className="px-4 md:px-6 py-2 md:py-3 bg-white/80 dark:bg-white/10 backdrop-blur-md border border-gray-300/50 dark:border-white/20 rounded-full transition-all duration-500">
            <div className="flex items-center space-x-2 md:space-x-3 text-gray-800 dark:text-gray-200">
              <div className="w-2 h-2 md:w-2.5 md:h-2.5 bg-green-500 rounded-full animate-pulse shadow-lg shadow-green-500/50"></div>
              <span className="text-xs md:text-sm font-medium">Available for projects</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;