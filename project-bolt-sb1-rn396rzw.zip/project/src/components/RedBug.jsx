import React, { useEffect, useRef, useState } from 'react';
import { gsap } from 'gsap';
import { Monitor, Check } from 'lucide-react';

const RedBug = () => {
  const containerRef = useRef(null);
  const bugRef = useRef(null);
  const glowRef = useRef(null);
  const [isClicked, setIsClicked] = useState(false);

  useEffect(() => {
    const container = containerRef.current;
    const bug = bugRef.current;
    const glow = glowRef.current;

    // Floating animation
    gsap.to(container, {
      y: -20,
      duration: 3,
      repeat: -1,
      yoyo: true,
      ease: "power2.inOut"
    });

    // Glow pulsing animation
    gsap.to(glow, {
      scale: 1.3,
      opacity: 0.8,
      duration: 2,
      repeat: -1,
      yoyo: true,
      ease: "power2.inOut"
    });

    // Random gentle movement
    const randomMove = () => {
      gsap.to(container, {
        x: (Math.random() - 0.5) * 30,
        duration: 4,
        ease: "power2.inOut",
        onComplete: randomMove
      });
    };

    randomMove();

    // Mouse interaction - bug moves away from cursor
    const handleMouseMove = (e) => {
      const rect = container.getBoundingClientRect();
      const centerX = rect.left + rect.width / 2;
      const centerY = rect.top + rect.height / 2;
      
      const deltaX = e.clientX - centerX;
      const deltaY = e.clientY - centerY;
      const distance = Math.sqrt(deltaX * deltaX + deltaY * deltaY);
      
      if (distance < 150) {
        // Bug moves away from cursor
        gsap.to(container, {
          x: -deltaX * 0.3,
          y: -deltaY * 0.3,
          duration: 0.6,
          ease: "power2.out"
        });
        
        // Increase glow when mouse is near
        gsap.to(glow, {
          scale: 1.6,
          opacity: 1,
          duration: 0.3
        });
      }
    };

    document.addEventListener('mousemove', handleMouseMove);

    return () => {
      document.removeEventListener('mousemove', handleMouseMove);
    };
  }, []);

  const handleClick = () => {
    if (!isClicked) {
      setIsClicked(true);
      
      // Transform animation
      gsap.to(bugRef.current, {
        scale: 0,
        rotation: 180,
        duration: 0.3,
        ease: "power2.in",
        onComplete: () => {
          gsap.fromTo(bugRef.current, 
            { scale: 0, rotation: -180 },
            { scale: 1, rotation: 0, duration: 0.4, ease: "back.out(1.7)" }
          );
        }
      });

      // Change glow color to green
      gsap.to(glowRef.current, {
        filter: 'hue-rotate(120deg)',
        duration: 0.5
      });

      // Reset after 3 seconds
      setTimeout(() => {
        setIsClicked(false);
        gsap.to(glowRef.current, {
          filter: 'hue-rotate(0deg)',
          duration: 0.5
        });
      }, 3000);
    }
  };

  return (
    <div 
      ref={containerRef}
      className="cursor-pointer z-30 p-4 flex items-center justify-center" 
      onClick={handleClick}
      role="button"
      aria-label="Interactive bug - click to fix"
      tabIndex={0}
    >
      {/* Computer monitor container with enhanced glow */}
      <div className="relative w-16 h-16 md:w-24 md:h-24 bg-gray-800 dark:bg-gray-700 rounded-lg border-2 border-gray-600 dark:border-gray-500 shadow-2xl flex items-center justify-center">
        {/* Enhanced glow for both themes */}
        <div className="absolute -inset-2 bg-gradient-to-r from-red-500/30 to-orange-500/30 dark:from-red-400/50 dark:to-orange-400/50 rounded-xl blur-lg opacity-80 dark:opacity-100 transition-all duration-500"></div>
        
        {/* Monitor screen */}
        <div className="relative w-12 h-12 md:w-20 md:h-20 bg-gray-900 dark:bg-black rounded border border-gray-700 dark:border-gray-600 overflow-hidden flex items-center justify-center">
          {/* Screen glow */}
          <div 
            ref={glowRef}
            className="absolute inset-0 bg-red-500/30 dark:bg-red-500/40 rounded animate-pulse"
          />
          
          {/* Bug or check mark */}
          <div 
            ref={bugRef}
            className="relative flex items-center justify-center"
          >
            {isClicked ? (
              <Check className="w-4 h-4 md:w-8 md:h-8 text-green-400 drop-shadow-lg" />
            ) : (
              <div className="relative flex items-center justify-center">
                {/* Bug body with enhanced glow */}
                <div className="w-3 h-4 md:w-6 md:h-8 bg-gradient-to-b from-red-400 to-red-600 rounded-full relative shadow-lg shadow-red-500/50 flex items-center justify-center">
                  {/* Bug spots */}
                  <div className="absolute top-0.5 md:top-1 left-0.5 md:left-1 w-0.5 h-0.5 md:w-1 md:h-1 bg-red-800 rounded-full"></div>
                  <div className="absolute top-1 md:top-2 right-0.5 md:right-1 w-0.5 h-0.5 bg-red-800 rounded-full"></div>
                  <div className="absolute bottom-1 md:bottom-2 left-1 md:left-1.5 w-0.5 h-0.5 bg-red-800 rounded-full"></div>
                  
                  {/* Antennae */}
                  <div className="absolute -top-0.5 md:-top-1 left-1/2 transform -translate-x-1/2">
                    <div className="w-0.5 h-1 md:h-2 bg-red-800 transform -rotate-12 origin-bottom"></div>
                    <div className="w-0.5 h-1 md:h-2 bg-red-800 transform rotate-12 origin-bottom absolute top-0"></div>
                  </div>
                </div>
                
                {/* Enhanced glow effect */}
                <div className="absolute inset-0 bg-red-500/60 dark:bg-red-400/70 rounded-full blur-sm scale-150"></div>
              </div>
            )}
          </div>
        </div>
        
        {/* Monitor stand */}
        <div className="absolute -bottom-1 md:-bottom-2 left-1/2 -translate-x-1/2 w-4 h-1 md:w-8 md:h-2 bg-gray-700 dark:bg-gray-600 rounded-b"></div>
        <div className="absolute -bottom-1.5 md:-bottom-3 left-1/2 -translate-x-1/2 w-6 h-0.5 md:w-12 md:h-1 bg-gray-600 dark:bg-gray-500 rounded"></div>
      </div>
    </div>
  );
};

export default RedBug;
