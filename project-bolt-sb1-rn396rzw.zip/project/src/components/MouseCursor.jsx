import React, { useEffect, useRef } from 'react';
import { gsap } from 'gsap';

const MouseCursor = () => {
  const cursorRef = useRef(null);
  const followerRef = useRef(null);
  const trailRef = useRef([]);

  useEffect(() => {
    const cursor = cursorRef.current;
    const follower = followerRef.current;
    const trail = trailRef.current;

    if (!cursor || !follower) return;

    // Create trail dots
    for (let i = 0; i < 6; i++) {
      const dot = document.createElement('div');
      dot.className = 'fixed w-1 h-1 bg-red-500/40 dark:bg-red-400/50 rounded-full pointer-events-none z-40 transition-opacity duration-300';
      dot.style.transform = 'translate(-50%, -50%)';
      document.body.appendChild(dot);
      trail.push(dot);
    }

    const moveCursor = (e) => {
      gsap.to(cursor, {
        x: e.clientX,
        y: e.clientY,
        duration: 0.05,
        ease: "power2.out"
      });

      gsap.to(follower, {
        x: e.clientX,
        y: e.clientY,
        duration: 0.15,
        ease: "power2.out"
      });

      // Animate trail
      trail.forEach((dot, index) => {
        gsap.to(dot, {
          x: e.clientX,
          y: e.clientY,
          duration: 0.2 + index * 0.03,
          ease: "power2.out"
        });
      });
    };

    const handleMouseEnter = () => {
      gsap.to([cursor, follower], {
        scale: 1.5,
        duration: 0.3,
        ease: "power2.out"
      });
      
      trail.forEach(dot => {
        gsap.to(dot, { opacity: 0.8, scale: 1.2, duration: 0.2 });
      });
    };

    const handleMouseLeave = () => {
      gsap.to([cursor, follower], {
        scale: 1,
        duration: 0.3,
        ease: "power2.out"
      });
      
      trail.forEach(dot => {
        gsap.to(dot, { opacity: 0.4, scale: 1, duration: 0.2 });
      });
    };

    document.addEventListener('mousemove', moveCursor);

    // Add hover effects to interactive elements
    const interactiveElements = document.querySelectorAll('button, a, .cursor-hover, input, textarea');
    interactiveElements.forEach(el => {
      el.addEventListener('mouseenter', handleMouseEnter);
      el.addEventListener('mouseleave', handleMouseLeave);
    });

    return () => {
      document.removeEventListener('mousemove', moveCursor);
      interactiveElements.forEach(el => {
        el.removeEventListener('mouseenter', handleMouseEnter);
        el.removeEventListener('mouseleave', handleMouseLeave);
      });
      trail.forEach(dot => {
        if (dot.parentNode) {
          dot.parentNode.removeChild(dot);
        }
      });
    };
  }, []);

  return (
    <div className="cursor-none relative">
      <div 
        ref={cursorRef}
        className="fixed top-0 left-0 w-2 h-2 bg-gradient-to-r from-red-500 to-red-600 dark:from-red-400 dark:to-red-500 rounded-full pointer-events-none z-50 shadow-lg"
        style={{ transform: 'translate(-50%, -50%)' }}
      >
        <div className="absolute inset-0 bg-gradient-to-r from-red-400 to-red-500 dark:from-red-300 dark:to-red-400 rounded-full animate-ping opacity-75"></div>
      </div>
      <div 
        ref={followerRef}
        className="fixed top-0 left-0 w-6 h-6 border border-red-500/60 dark:border-red-400/60 rounded-full pointer-events-none z-40"
        style={{ transform: 'translate(-50%, -50%)' }}
      />
    </div>
  );
};

export default MouseCursor;