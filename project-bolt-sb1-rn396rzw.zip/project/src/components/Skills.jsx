import React, { useEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import data from '../data.json';

gsap.registerPlugin(ScrollTrigger);

const Skills = () => {
  const sectionRef = useRef(null);
  const sliderRef = useRef(null);
  const titleRef = useRef(null);

  useEffect(() => {
    const section = sectionRef.current;
    const slider = sliderRef.current;
    const title = titleRef.current;

    // Title animation
    gsap.fromTo(title,
      { y: 50, opacity: 0 },
      {
        y: 0,
        opacity: 1,
        duration: 1,
        ease: "power3.out",
        scrollTrigger: {
          trigger: section,
          start: "top 80%",
        }
      }
    );

    // Infinite horizontal scroll
    const logos = slider.children;
    const logoWidth = 200; // Width of each logo container
    const totalWidth = logoWidth * logos.length;

    gsap.set(slider, { x: 0 });
    
    const scrollAnimation = gsap.to(slider, {
      x: -totalWidth,
      duration: 30,
      repeat: -1,
      ease: "none"
    });

    // Hover pause effect
    slider.addEventListener('mouseenter', () => {
      scrollAnimation.pause();
    });

    slider.addEventListener('mouseleave', () => {
      scrollAnimation.resume();
    });

    return () => {
      ScrollTrigger.getAll().forEach(trigger => trigger.kill());
      scrollAnimation.kill();
    };
  }, []);

  const technologies = [
    { name: 'React', emoji: '⚛️', color: 'from-blue-400 to-blue-600' },
    { name: 'JavaScript', emoji: '🟨', color: 'from-yellow-400 to-yellow-600' },
    { name: 'TypeScript', emoji: '🔷', color: 'from-blue-500 to-blue-700' },
    { name: 'Node.js', emoji: '🟢', color: 'from-green-400 to-green-600' },
    { name: 'CSS3', emoji: '🎨', color: 'from-pink-400 to-pink-600' },
    { name: 'HTML5', emoji: '🌐', color: 'from-orange-400 to-orange-600' },
    { name: 'GSAP', emoji: '✨', color: 'from-purple-400 to-purple-600' },
    { name: 'Three.js', emoji: '🎲', color: 'from-indigo-400 to-indigo-600' },
    { name: 'Git', emoji: '📚', color: 'from-red-400 to-red-600' },
    { name: 'Figma', emoji: '🎯', color: 'from-cyan-400 to-cyan-600' },
    // Duplicate for seamless loop
    { name: 'React', emoji: '⚛️', color: 'from-blue-400 to-blue-600' },
    { name: 'JavaScript', emoji: '🟨', color: 'from-yellow-400 to-yellow-600' },
    { name: 'TypeScript', emoji: '🔷', color: 'from-blue-500 to-blue-700' },
    { name: 'Node.js', emoji: '🟢', color: 'from-green-400 to-green-600' }
  ];

  return (
    <section 
      id="skills" 
      ref={sectionRef} 
      className="py-12 md:py-24 bg-gray-50 dark:bg-gray-800 transition-colors duration-500 relative overflow-hidden"
      role="main"
    >
      {/* Enhanced background effects for light theme */}
      <div className="absolute inset-0 opacity-100 dark:opacity-0 transition-opacity duration-500">
        <div className="absolute top-20 left-1/4 w-72 h-72 bg-gradient-radial from-blue-200/40 via-purple-200/30 to-transparent rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute bottom-20 right-1/4 w-96 h-96 bg-gradient-radial from-purple-200/40 via-pink-200/30 to-transparent rounded-full blur-3xl animate-pulse delay-1000"></div>
      </div>

      {/* Dark theme background effects */}
      <div className="absolute inset-0 opacity-0 dark:opacity-20 transition-opacity duration-500">
        <div className="absolute top-20 left-1/4 w-72 h-72 bg-gradient-radial from-blue-500/50 via-purple-500/40 to-transparent rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute bottom-20 right-1/4 w-96 h-96 bg-gradient-radial from-purple-500/50 via-pink-500/40 to-transparent rounded-full blur-3xl animate-pulse delay-1000"></div>
      </div>

      {/* Golden ratio layout: 38% for title, 62% for content */}
      <div className="flex flex-col h-full">
        <div className="h-auto lg:h-[38%] flex items-center justify-center px-6 md:px-12 py-8 lg:py-0">
          <h2 ref={titleRef} className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-bold text-center text-gray-900 dark:text-white leading-tight transition-colors duration-500">
            Tech I Use
          </h2>
        </div>
        
        <div className="h-auto lg:h-[62%] flex items-center py-8 lg:py-0">
          <div className="w-full overflow-hidden">
            <div 
              ref={sliderRef}
              className="flex items-center space-x-6 md:space-x-8"
              style={{ width: 'max-content' }}
            >
              {technologies.map((tech, index) => (
                <div
                  key={`${tech.name}-${index}`}
                  className="flex-shrink-0 w-32 h-24 md:w-48 md:h-32 group cursor-hover"
                >
                  <div className="relative w-full h-full bg-white/90 dark:bg-white/5 backdrop-blur-md border border-gray-300/50 dark:border-white/10 rounded-2xl flex flex-col items-center justify-center hover:bg-white dark:hover:bg-white/10 hover:border-gray-400/50 dark:hover:border-white/20 hover:scale-110 transition-all duration-500 group">
                    <div className={`absolute inset-0 bg-gradient-to-br ${tech.color} opacity-0 group-hover:opacity-30 dark:group-hover:opacity-20 rounded-2xl transition-opacity duration-500`}></div>
                    
                    <div className="text-2xl md:text-4xl mb-2 md:mb-3 group-hover:scale-125 transition-transform duration-300">
                      {tech.emoji}
                    </div>
                    
                    <h3 className="text-sm md:text-lg font-semibold text-gray-900 dark:text-white transition-all duration-300">
                      {tech.name}
                    </h3>
                    
                    {/* Enhanced glow effect */}
                    <div className={`absolute inset-0 bg-gradient-to-br ${tech.color} opacity-0 group-hover:opacity-20 dark:group-hover:opacity-10 rounded-2xl blur-xl scale-110 transition-opacity duration-500`}></div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Skills;