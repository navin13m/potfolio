import React, { useEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { ExternalLink, Github, ArrowRight } from 'lucide-react';
import data from '../data.json';

gsap.registerPlugin(ScrollTrigger);

const Projects = () => {
  const sectionRef = useRef(null);
  const titleRef = useRef(null);
  const projectsRef = useRef([]);

  useEffect(() => {
    const section = sectionRef.current;
    const title = titleRef.current;

    gsap.fromTo(title,
      { y: 50, opacity: 0 },
      {
        y: 0,
        opacity: 1,
        duration: 1,
        ease: "power3.out",
        scrollTrigger: {
          trigger: section,
          start: "top 80%",
        }
      }
    );

    // Staggered project animations
    projectsRef.current.forEach((project, index) => {
      if (project) {
        gsap.fromTo(project,
          { y: 60, opacity: 0, scale: 0.95 },
          {
            y: 0,
            opacity: 1,
            scale: 1,
            duration: 1,
            delay: index * 0.2,
            ease: "power3.out",
            scrollTrigger: {
              trigger: project,
              start: "top 85%",
            }
          }
        );
      }
    });
  }, []);

  return (
    <section 
      id="projects" 
      ref={sectionRef} 
      className="py-16 md:py-20 bg-gray-50 dark:bg-gray-800 transition-colors duration-500 relative overflow-hidden"
      role="main"
    >
      {/* Enhanced background effects for light theme */}
      <div className="absolute inset-0 opacity-100 dark:opacity-0 transition-opacity duration-500">
        <div className="absolute top-20 left-20 w-80 h-80 bg-gradient-radial from-purple-200/40 via-blue-200/30 to-transparent rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute bottom-20 right-20 w-96 h-96 bg-gradient-radial from-red-200/40 via-orange-200/30 to-transparent rounded-full blur-3xl animate-pulse delay-1000"></div>
      </div>

      {/* Dark theme background effects */}
      <div className="absolute inset-0 opacity-0 dark:opacity-15 transition-opacity duration-500">
        <div className="absolute top-40 left-20 w-80 h-80 bg-gradient-radial from-purple-500/50 via-blue-500/40 to-transparent rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute bottom-40 right-20 w-96 h-96 bg-gradient-radial from-red-500/50 via-orange-500/40 to-transparent rounded-full blur-3xl animate-pulse delay-1000"></div>
      </div>
      
      <div className="max-w-7xl mx-auto px-4 md:px-6 lg:px-12">
        <h2 ref={titleRef} className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-bold text-center text-gray-900 dark:text-white mb-12 md:mb-16 transition-colors duration-500">
          Featured Projects
        </h2>

        <div className="space-y-12 md:space-y-16 lg:space-y-20">
          {data.projects.map((project, index) => (
            <article
              key={project.id}
              ref={el => projectsRef.current[index] = el}
              className={`flex flex-col ${index % 2 === 0 ? 'lg:flex-row' : 'lg:flex-row-reverse'} items-center gap-8 lg:gap-12 xl:gap-16`}
            >
              {/* Project Image */}
              <div className="w-full lg:w-1/2 relative group">
                <div className="relative overflow-hidden rounded-2xl">
                  <img
                    src={project.image}
                    alt={`${project.title} - ${project.description}`}
                    className="w-full h-48 md:h-56 lg:h-64 xl:h-72 object-cover group-hover:scale-105 transition-transform duration-700"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-gray-900/60 dark:from-gray-900/80 via-transparent to-transparent"></div>
                  
                  {/* Hover overlay with enhanced visibility */}
                  <div className="absolute inset-0 bg-gradient-to-br from-red-500/20 via-purple-500/20 to-blue-500/20 dark:from-red-500/30 dark:via-purple-500/30 dark:to-blue-500/30 opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
                </div>
                
                {/* Floating tech badges */}
                <div className="absolute top-4 left-4 flex flex-wrap gap-2 opacity-0 group-hover:opacity-100 transition-opacity duration-500">
                  {project.technologies.slice(0, 3).map((tech, techIndex) => (
                    <span
                      key={techIndex}
                      className="px-2 md:px-3 py-1 bg-white/95 dark:bg-gray-900/95 backdrop-blur-md text-gray-900 dark:text-white text-xs rounded-full font-medium shadow-lg"
                    >
                      {tech}
                    </span>
                  ))}
                </div>
              </div>

              {/* Project Content */}
              <div className="w-full lg:w-1/2 space-y-4 md:space-y-6 px-4 lg:px-0">
                <div>
                  <h3 className="text-2xl md:text-3xl lg:text-4xl font-bold text-gray-900 dark:text-white mb-3 md:mb-4 leading-tight transition-colors duration-500">
                    {project.title}
                  </h3>
                  
                  <p className="text-base md:text-lg text-gray-800 dark:text-gray-100 leading-relaxed mb-4 md:mb-6 transition-colors duration-500">
                    {project.description}
                  </p>

                  <div className="flex flex-wrap gap-2 mb-6 md:mb-8">
                    {project.technologies.map((tech, techIndex) => (
                      <span
                        key={techIndex}
                        className="px-2 md:px-3 py-1 bg-gray-200/80 dark:bg-white/5 backdrop-blur-md border border-gray-300/50 dark:border-white/10 text-gray-800 dark:text-gray-200 text-xs md:text-sm rounded-full font-medium hover:bg-gray-300/80 dark:hover:bg-white/10 hover:border-gray-400/50 dark:hover:border-white/20 transition-all duration-300"
                      >
                        {tech}
                      </span>
                    ))}
                  </div>
                </div>

                <div className="flex flex-col sm:flex-row space-y-3 sm:space-y-0 sm:space-x-4">
                  <a
                    href={project.liveUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="cursor-hover group inline-flex items-center justify-center px-4 md:px-6 py-2 md:py-3 bg-gradient-to-r from-red-500 to-red-600 dark:from-red-600 dark:to-red-700 text-white rounded-xl hover:shadow-lg hover:shadow-red-500/30 dark:hover:shadow-red-500/50 transform hover:scale-105 transition-all duration-300 font-medium text-sm md:text-base"
                    aria-label={`View live demo of ${project.title}`}
                  >
                    <ExternalLink className="w-4 h-4 mr-2" />
                    Live Demo
                    <ArrowRight className="w-4 h-4 ml-2 group-hover:translate-x-1 transition-transform duration-300" />
                  </a>
                  
                  <a
                    href={project.githubUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="cursor-hover inline-flex items-center justify-center px-4 md:px-6 py-2 md:py-3 bg-white/90 dark:bg-white/10 backdrop-blur-md border border-gray-300/50 dark:border-white/20 text-gray-900 dark:text-white rounded-xl hover:bg-gray-100/90 dark:hover:bg-white/20 hover:border-gray-400/50 dark:hover:border-white/30 transition-all duration-300 font-medium text-sm md:text-base"
                    aria-label={`View source code of ${project.title}`}
                  >
                    <Github className="w-4 h-4 mr-2" />
                    View Code
                  </a>
                </div>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Projects;