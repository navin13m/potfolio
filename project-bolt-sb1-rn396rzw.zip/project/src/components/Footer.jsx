import React from 'react';
import { Github, Linkedin, Twitter, Instagram, Mail, Heart } from 'lucide-react';

const Footer = () => {
  const currentYear = new Date().getFullYear();

  const socialLinks = [
    { icon: Github, href: "https://github.com", color: "hover:text-gray-600 dark:hover:text-gray-300", label: "GitHub" },
    { icon: Linkedin, href: "https://linkedin.com", color: "hover:text-blue-600 dark:hover:text-blue-400", label: "LinkedIn" },
    { icon: Twitter, href: "https://twitter.com", color: "hover:text-sky-600 dark:hover:text-sky-400", label: "Twitter" },
    { icon: Instagram, href: "https://instagram.com/naveen", color: "hover:text-pink-600 dark:hover:text-pink-400", label: "Instagram" },
    { icon: Mail, href: "mailto:naveen@email.com", color: "hover:text-red-600 dark:hover:text-red-400", label: "Email" }
  ];

  return (
    <footer className="bg-gray-100 dark:bg-black text-gray-900 dark:text-white py-12 md:py-16 relative overflow-hidden transition-colors duration-500" role="contentinfo">
      {/* Enhanced background animation for light theme */}
      <div className="absolute inset-0 opacity-100 dark:opacity-0 transition-opacity duration-500">
        <div className="absolute top-0 left-1/4 w-64 h-64 bg-gradient-radial from-red-200/40 via-orange-200/30 to-transparent rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute bottom-0 right-1/4 w-80 h-80 bg-gradient-radial from-purple-200/40 via-blue-200/30 to-transparent rounded-full blur-3xl animate-pulse delay-1000"></div>
      </div>

      {/* Dark theme background animation */}
      <div className="absolute inset-0 opacity-0 dark:opacity-20 transition-opacity duration-500">
        <div className="absolute top-0 left-1/4 w-64 h-64 bg-gradient-radial from-red-500/50 via-orange-500/40 to-transparent rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute bottom-0 right-1/4 w-80 h-80 bg-gradient-radial from-purple-500/50 via-blue-500/40 to-transparent rounded-full blur-3xl animate-pulse delay-1000"></div>
      </div>
      
      <div className="max-w-6xl mx-auto px-4 md:px-6 lg:px-12">
        <div className="text-center">
          <div className="flex flex-wrap justify-center gap-4 md:gap-6 lg:gap-8 mb-8 md:mb-12 relative z-10">
            {socialLinks.map(({ icon: Icon, href, color, label }, index) => (
              <a
                key={index}
                href={href}
                target="_blank"
                rel="noopener noreferrer"
                className={`cursor-hover p-3 md:p-4 bg-white/90 dark:bg-white/5 backdrop-blur-md border border-gray-300/50 dark:border-white/10 rounded-full ${color} hover:scale-110 hover:bg-gray-100/90 dark:hover:bg-white/10 transition-all duration-300 group`}
                aria-label={label}
              >
                <Icon className="w-5 h-5 md:w-6 md:h-6" />
              </a>
            ))}
          </div>

          <div className="border-t border-gray-300/50 dark:border-gray-800 pt-6 md:pt-8 relative z-10">
            <div className="inline-block px-6 md:px-8 py-2 md:py-3 bg-white/90 dark:bg-white/5 backdrop-blur-md border border-gray-300/50 dark:border-white/10 rounded-full mb-4 md:mb-6">
              <p className="text-gray-800 dark:text-gray-200 flex items-center justify-center text-sm md:text-base">
                Made with <Heart className="w-3 h-3 md:w-4 md:h-4 mx-2 text-red-500 animate-pulse" /> and lots of coffee
              </p>
            </div>
            <p className="text-gray-600 dark:text-gray-400 text-sm md:text-base">
              © {currentYear} Naveen. All rights reserved.
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;