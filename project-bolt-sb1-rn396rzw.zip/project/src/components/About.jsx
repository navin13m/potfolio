import React, { useEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { MapPin, Mail } from 'lucide-react';
import data from '../data.json';

gsap.registerPlugin(ScrollTrigger);

const About = () => {
  const sectionRef = useRef(null);
  const leftRef = useRef(null);
  const rightRef = useRef(null);

  useEffect(() => {
    const section = sectionRef.current;
    const left = leftRef.current;
    const right = rightRef.current;

    // Golden ratio layout animations
    gsap.fromTo([left, right], 
      { y: 80, opacity: 0 },
      {
        y: 0,
        opacity: 1,
        duration: 1.2,
        stagger: 0.3,
        ease: "power3.out",
        scrollTrigger: {
          trigger: section,
          start: "top 70%",
          end: "bottom 30%",
        }
      }
    );

    // Parallax effect for the image
    gsap.to(right, {
      y: -50,
      scrollTrigger: {
        trigger: section,
        start: "top bottom",
        end: "bottom top",
        scrub: 1
      }
    });
  }, []);

  return (
    <section 
      id="about" 
      ref={sectionRef} 
      className="min-h-screen py-12 md:py-24 bg-white dark:bg-gray-900 transition-colors duration-500 relative overflow-hidden"
      role="main"
    >
      {/* Enhanced background effects for light theme */}
      <div className="absolute inset-0 opacity-100 dark:opacity-0 transition-opacity duration-500">
        <div className="absolute top-20 left-20 w-72 h-72 bg-gradient-radial from-blue-200/30 via-purple-200/20 to-transparent rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute bottom-20 right-20 w-96 h-96 bg-gradient-radial from-purple-200/30 via-pink-200/20 to-transparent rounded-full blur-3xl animate-pulse delay-1000"></div>
      </div>

      {/* Dark theme background effects */}
      <div className="absolute inset-0 opacity-0 dark:opacity-20 transition-opacity duration-500">
        <div className="absolute top-20 left-20 w-72 h-72 bg-gradient-radial from-blue-500/50 via-purple-500/40 to-transparent rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute bottom-20 right-20 w-96 h-96 bg-gradient-radial from-purple-500/50 via-pink-500/40 to-transparent rounded-full blur-3xl animate-pulse delay-1000"></div>
      </div>
      
      {/* Golden ratio layout: 62% left, 38% right */}
      <div className="flex flex-col lg:flex-row min-h-screen">
        <div ref={leftRef} className="w-full lg:w-[62%] flex items-center justify-center px-6 md:px-12 lg:px-20 py-8 lg:py-0">
          <div className="max-w-2xl">
            <h2 className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-bold text-gray-900 dark:text-white mb-8 md:mb-12 leading-tight transition-colors duration-500">
              About Me
            </h2>
            
            <div className="space-y-6 md:space-y-8">
              <p className="text-lg md:text-xl lg:text-2xl text-gray-800 dark:text-gray-100 leading-relaxed transition-colors duration-500">
                {data.developer.bio}
              </p>
            </div>

            <div className="mt-8 md:mt-12 space-y-4 md:space-y-6">
              <div className="flex items-center space-x-4 text-gray-800 dark:text-gray-100 text-base md:text-lg transition-colors duration-500">
                <div className="w-10 h-10 md:w-12 md:h-12 bg-blue-200/80 dark:bg-blue-500/20 backdrop-blur-md border border-blue-300/50 dark:border-blue-500/30 rounded-full flex items-center justify-center">
                  <MapPin className="w-4 h-4 md:w-6 md:h-6 text-blue-700 dark:text-blue-400" />
                </div>
                <span>{data.developer.location}</span>
              </div>
              <div className="flex items-center space-x-4 text-gray-800 dark:text-gray-100 text-base md:text-lg transition-colors duration-500">
                <div className="w-10 h-10 md:w-12 md:h-12 bg-red-200/80 dark:bg-red-500/20 backdrop-blur-md border border-red-300/50 dark:border-red-500/30 rounded-full flex items-center justify-center">
                  <Mail className="w-4 h-4 md:w-6 md:h-6 text-red-700 dark:text-red-400" />
                </div>
                <span>{data.developer.email}</span>
              </div>
            </div>
          </div>
        </div>

        <div ref={rightRef} className="w-full lg:w-[38%] flex items-center justify-center px-6 md:px-12 lg:px-20 py-8 lg:py-0">
          <div className="relative">
            <div className="w-64 h-80 md:w-80 md:h-96 bg-white/80 dark:bg-white/10 backdrop-blur-md border border-gray-300/50 dark:border-white/20 rounded-3xl overflow-hidden shadow-2xl transition-all duration-500">
              <img
                src="https://images.pexels.com/photos/3184291/pexels-photo-3184291.jpeg?auto=compress&cs=tinysrgb&w=800"
                alt="Developer workspace showing modern coding environment"
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-gray-900/60 dark:from-gray-900/80 via-transparent to-transparent"></div>
            </div>
            
            {/* Floating decorative elements with enhanced visibility */}
            <div className="absolute -top-4 md:-top-8 -right-4 md:-right-8 w-16 h-16 md:w-24 md:h-24 bg-gradient-to-r from-red-400/60 via-red-500/50 to-red-600/60 dark:from-red-400/70 dark:via-red-500/60 dark:to-red-600/70 rounded-full blur-2xl animate-pulse transition-all duration-500"></div>
            <div className="absolute -bottom-4 md:-bottom-8 -left-4 md:-left-8 w-20 h-20 md:w-32 md:h-32 bg-gradient-to-r from-blue-400/60 via-purple-500/50 to-purple-600/60 dark:from-blue-400/70 dark:via-purple-500/60 dark:to-purple-600/70 rounded-full blur-2xl animate-pulse delay-1000 transition-all duration-500"></div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;