import React, { useEffect, useRef } from 'react';
import { gsap } from 'gsap';

const BackgroundAnimation = () => {
  const containerRef = useRef(null);
  const moonRef = useRef(null);
  const particlesRef = useRef([]);

  useEffect(() => {
    const container = containerRef.current;
    const moon = moonRef.current;

    // Create floating particles
    const createParticles = () => {
      for (let i = 0; i < 20; i++) {
        const particle = document.createElement('div');
        particle.className = 'absolute w-1 h-1 bg-white/20 dark:bg-white/40 rounded-full';
        particle.style.left = Math.random() * 100 + '%';
        particle.style.top = Math.random() * 100 + '%';
        container.appendChild(particle);
        particlesRef.current.push(particle);

        // Animate particles
        gsap.to(particle, {
          y: -100,
          x: Math.random() * 50 - 25,
          opacity: 0,
          duration: Math.random() * 10 + 5,
          repeat: -1,
          ease: "none",
          delay: Math.random() * 5
        });
      }
    };

    createParticles();

    // Moon floating animation
    gsap.to(moon, {
      y: -15,
      duration: 6,
      repeat: -1,
      yoyo: true,
      ease: "power2.inOut"
    });

    // Gentle rotation
    gsap.to(moon, {
      rotation: 360,
      duration: 200,
      repeat: -1,
      ease: "none"
    });

    // Theme-responsive glow
    const updateMoonGlow = () => {
      const isDark = document.documentElement.classList.contains('dark');
      
      gsap.to('.moon-glow', {
        opacity: isDark ? 0.9 : 0.3,
        scale: isDark ? 1.4 : 0.8,
        duration: 1,
        ease: "power2.inOut"
      });
    };

    const observer = new MutationObserver(updateMoonGlow);
    observer.observe(document.documentElement, {
      attributes: true,
      attributeFilter: ['class']
    });

    updateMoonGlow();

    return () => {
      observer.disconnect();
      particlesRef.current.forEach(particle => {
        if (particle.parentNode) {
          particle.parentNode.removeChild(particle);
        }
      });
    };
  }, []);

  return (
    <div 
      ref={containerRef}
      className="fixed inset-0 -z-20 overflow-hidden transition-all duration-500"
    >
      {/* Main background with enhanced light & dark theme */}
      <div className="absolute inset-0 bg-gradient-to-br from-gray-50 via-blue-50 to-purple-50 dark:from-gray-900 dark:via-blue-900/50 dark:to-purple-900/30 transition-all duration-500"></div>
      
      {/* Light theme glow enhancements */}
      <div className="absolute inset-0 opacity-100 dark:opacity-0 transition-opacity duration-500">
        <div className="absolute top-20 left-10 sm:left-20 w-72 h-72 sm:w-96 sm:h-96 bg-gradient-radial from-blue-200/30 via-purple-200/20 to-transparent rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute bottom-20 right-1/4 w-64 h-64 sm:w-80 sm:h-80 bg-gradient-radial from-purple-200/30 via-pink-200/20 to-transparent rounded-full blur-3xl animate-pulse delay-1000"></div>
        <div className="absolute top-1/2 left-1/3 w-48 h-48 sm:w-64 sm:h-64 bg-gradient-radial from-yellow-200/20 via-orange-200/15 to-transparent rounded-full blur-3xl animate-pulse delay-2000"></div>
      </div>

      {/* Moon positioned far right, responsive safe */}
      <div 
        ref={moonRef}
        className="absolute top-40 sm:top-32 right-[-8rem] sm:right-[-5rem] w-40 h-40 sm:w-60 sm:h-60 md:w-80 md:h-80"
      >
        <div className="relative w-full h-full">
          <img 
            src="https://images.pexels.com/photos/1118873/pexels-photo-1118873.jpeg?auto=compress&cs=tinysrgb&w=800"
            alt="Glowing moon background"
            className="w-full h-full object-cover rounded-full opacity-50 dark:opacity-80 transition-opacity duration-500"
            loading="lazy"
          />
          
          {/* Moon glow effect */}
          <div className="moon-glow absolute inset-0 bg-gradient-radial from-yellow-200/30 via-blue-200/15 to-transparent dark:from-blue-300/50 dark:via-purple-300/25 dark:to-transparent rounded-full blur-3xl scale-150 transition-all duration-500"></div>
          
          {/* Extra glow in dark theme */}
          <div className="absolute inset-0 bg-gradient-radial from-white/5 via-blue-100/5 to-transparent dark:from-blue-400/40 dark:via-purple-400/20 dark:to-transparent rounded-full blur-2xl scale-125 opacity-0 dark:opacity-100 transition-all duration-500"></div>
        </div>
      </div>
    </div>
  );
};

export default BackgroundAnimation;
