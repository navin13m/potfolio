import React, { useEffect, useRef, useState } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Send, Check, Mail, Instagram } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

const Contact = () => {
  const sectionRef = useRef(null);
  const leftRef = useRef(null);
  const rightRef = useRef(null);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    message: ''
  });
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [errors, setErrors] = useState({});

  useEffect(() => {
    const section = sectionRef.current;
    const left = leftRef.current;
    const right = rightRef.current;

    // Golden ratio animations
    gsap.fromTo([left, right],
      { y: 80, opacity: 0 },
      {
        y: 0,
        opacity: 1,
        duration: 1.2,
        stagger: 0.3,
        ease: "power3.out",
        scrollTrigger: {
          trigger: section,
          start: "top 70%",
        }
      }
    );
  }, []);

  const validateForm = () => {
    const newErrors = {};

    if (!formData.name.trim()) {
      newErrors.name = 'Name is required';
    }

    if (!formData.email.trim()) {
      newErrors.email = 'Email is required';
    } else if (!/\S+@\S+\.\S+/.test(formData.email)) {
      newErrors.email = 'Email is invalid';
    }

    if (!formData.message.trim()) {
      newErrors.message = 'Message is required';
    } else if (formData.message.length < 10) {
      newErrors.message = 'Message must be at least 10 characters';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    
    if (validateForm()) {
      setIsSubmitted(true);
      setTimeout(() => {
        setIsSubmitted(false);
        setFormData({ name: '', email: '', message: '' });
      }, 3000);
    }
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
    
    if (errors[name]) {
      setErrors(prev => ({ ...prev, [name]: '' }));
    }
  };

  return (
    <section 
      id="contact" 
      ref={sectionRef} 
      className="min-h-screen py-12 md:py-24 bg-white dark:bg-gray-900 transition-colors duration-500 relative overflow-hidden"
      role="main"
    >
      {/* Enhanced background effects for light theme */}
      <div className="absolute inset-0 opacity-100 dark:opacity-0 transition-opacity duration-500">
        <div className="absolute top-20 left-20 w-80 h-80 bg-gradient-radial from-red-200/40 via-orange-200/30 to-transparent rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute bottom-20 right-20 w-96 h-96 bg-gradient-radial from-purple-200/40 via-blue-200/30 to-transparent rounded-full blur-3xl animate-pulse delay-1000"></div>
      </div>

      {/* Dark theme background effects */}
      <div className="absolute inset-0 opacity-0 dark:opacity-20 transition-opacity duration-500">
        <div className="absolute top-20 left-20 w-80 h-80 bg-gradient-radial from-red-500/50 via-orange-500/40 to-transparent rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute bottom-20 right-20 w-96 h-96 bg-gradient-radial from-purple-500/50 via-blue-500/40 to-transparent rounded-full blur-3xl animate-pulse delay-1000"></div>
      </div>
      
      {/* Golden ratio layout: 38% left, 62% right */}
      <div className="flex flex-col lg:flex-row min-h-screen">
        <div ref={leftRef} className="w-full lg:w-[38%] flex flex-col justify-center px-6 md:px-12 lg:px-20 py-8 lg:py-0">
          <h2 className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-bold text-gray-900 dark:text-white mb-8 md:mb-12 leading-tight transition-colors duration-500">
            Let's Work
            <br />
            <span className="bg-gradient-to-r from-red-500 to-red-600 dark:from-red-400 dark:to-red-500 bg-clip-text text-transparent">
              Together
            </span>
          </h2>
          
          <p className="text-lg md:text-xl text-gray-800 dark:text-gray-100 mb-12 md:mb-16 leading-relaxed transition-colors duration-500">
            Have a project in mind? I'd love to hear about it. Let's create something amazing together.
          </p>

          {/* Contact Options */}
          <div className="space-y-4 md:space-y-6">
            <a
              href="mailto:naveen@email.com"
              className="cursor-hover group flex items-center space-x-4 text-gray-800 dark:text-gray-100 hover:text-gray-900 dark:hover:text-white transition-colors duration-300"
              aria-label="Send email to Naveen"
            >
              <div className="w-12 h-12 md:w-14 md:h-14 bg-red-200/80 dark:bg-red-500/20 backdrop-blur-md border border-red-300/50 dark:border-red-500/30 rounded-full flex items-center justify-center group-hover:scale-110 group-hover:shadow-lg group-hover:shadow-red-500/30 transition-all duration-300">
                <Mail className="w-5 h-5 md:w-6 md:h-6 text-red-700 dark:text-red-400" />
              </div>
              <div>
                <p className="text-base md:text-lg font-medium">Email</p>
                <p className="text-sm md:text-base text-gray-600 dark:text-gray-400">naveen@email.com</p>
              </div>
            </a>

            <a
              href="https://instagram.com/naveen"
              target="_blank"
              rel="noopener noreferrer"
              className="cursor-hover group flex items-center space-x-4 text-gray-800 dark:text-gray-100 hover:text-gray-900 dark:hover:text-white transition-colors duration-300"
              aria-label="Follow Naveen on Instagram"
            >
              <div className="w-12 h-12 md:w-14 md:h-14 bg-pink-200/80 dark:bg-pink-500/20 backdrop-blur-md border border-pink-300/50 dark:border-pink-500/30 rounded-full flex items-center justify-center group-hover:scale-110 group-hover:shadow-lg group-hover:shadow-pink-500/30 transition-all duration-300">
                <Instagram className="w-5 h-5 md:w-6 md:h-6 text-pink-700 dark:text-pink-400" />
              </div>
              <div>
                <p className="text-base md:text-lg font-medium">Instagram</p>
                <p className="text-sm md:text-base text-gray-600 dark:text-gray-400">@naveen</p>
              </div>
            </a>
          </div>
        </div>

        <div ref={rightRef} className="w-full lg:w-[62%] flex items-center justify-center px-6 md:px-12 lg:px-20 py-8 lg:py-0">
          {isSubmitted ? (
            <div className="text-center">
              <div className="w-16 h-16 md:w-24 md:h-24 mx-auto mb-6 md:mb-8 bg-green-200/80 dark:bg-green-500/20 backdrop-blur-md border border-green-300/50 dark:border-green-500/30 rounded-full flex items-center justify-center">
                <Check className="w-8 h-8 md:w-12 md:h-12 text-green-700 dark:text-green-400" />
              </div>
              <h3 className="text-2xl md:text-3xl font-bold text-green-700 dark:text-green-400 mb-4">Message Sent!</h3>
              <p className="text-lg md:text-xl text-green-600 dark:text-green-300">Thank you for reaching out. I'll get back to you soon.</p>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="w-full max-w-2xl space-y-4 md:space-y-6">
              <div className="grid md:grid-cols-2 gap-4 md:gap-6">
                <div>
                  <label htmlFor="name" className="block text-base md:text-lg font-medium text-gray-900 dark:text-gray-100 mb-2 transition-colors duration-500">
                    Name *
                  </label>
                  <input
                    type="text"
                    id="name"
                    name="name"
                    value={formData.name}
                    onChange={handleChange}
                    className={`w-full px-3 md:px-4 py-2 md:py-3 bg-white/90 dark:bg-white/5 backdrop-blur-md border ${
                      errors.name ? 'border-red-500/50' : 'border-gray-300/50 dark:border-white/10'
                    } rounded-xl text-gray-900 dark:text-white placeholder-gray-500 dark:placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-red-500/50 focus:border-red-500/50 transition-all duration-300 text-sm md:text-base`}
                    placeholder="Your name"
                  />
                  {errors.name && <p className="text-red-500 dark:text-red-400 text-xs md:text-sm mt-1">{errors.name}</p>}
                </div>

                <div>
                  <label htmlFor="email" className="block text-base md:text-lg font-medium text-gray-900 dark:text-gray-100 mb-2 transition-colors duration-500">
                    Email *
                  </label>
                  <input
                    type="email"
                    id="email"
                    name="email"
                    value={formData.email}
                    onChange={handleChange}
                    className={`w-full px-3 md:px-4 py-2 md:py-3 bg-white/90 dark:bg-white/5 backdrop-blur-md border ${
                      errors.email ? 'border-red-500/50' : 'border-gray-300/50 dark:border-white/10'
                    } rounded-xl text-gray-900 dark:text-white placeholder-gray-500 dark:placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-red-500/50 focus:border-red-500/50 transition-all duration-300 text-sm md:text-base`}
                    placeholder="your.email@example.com"
                  />
                  {errors.email && <p className="text-red-500 dark:text-red-400 text-xs md:text-sm mt-1">{errors.email}</p>}
                </div>
              </div>

              <div>
                <label htmlFor="message" className="block text-base md:text-lg font-medium text-gray-900 dark:text-gray-100 mb-2 transition-colors duration-500">
                  Message *
                </label>
                <textarea
                  id="message"
                  name="message"
                  rows="4"
                  value={formData.message}
                  onChange={handleChange}
                  className={`w-full px-3 md:px-4 py-2 md:py-3 bg-white/90 dark:bg-white/5 backdrop-blur-md border ${
                    errors.message ? 'border-red-500/50' : 'border-gray-300/50 dark:border-white/10'
                  } rounded-xl text-gray-900 dark:text-white placeholder-gray-500 dark:placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-red-500/50 focus:border-red-500/50 transition-all duration-300 resize-none text-sm md:text-base`}
                  placeholder="Tell me about your project..."
                ></textarea>
                {errors.message && <p className="text-red-500 dark:text-red-400 text-xs md:text-sm mt-1">{errors.message}</p>}
              </div>

              <button
                type="submit"
                className="cursor-hover w-full bg-gradient-to-r from-red-500 to-red-600 dark:from-red-600 dark:to-red-700 text-white font-semibold py-3 md:py-4 px-6 md:px-8 rounded-xl hover:shadow-xl hover:shadow-red-500/30 dark:hover:shadow-red-500/50 transform hover:scale-105 transition-all duration-300 flex items-center justify-center relative overflow-hidden group text-sm md:text-lg"
                aria-label="Send message"
              >
                <div className="absolute inset-0 bg-gradient-to-r from-red-600 to-red-700 dark:from-red-700 dark:to-red-800 opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
                <span className="relative z-10 flex items-center">
                  <Send className="w-4 h-4 md:w-5 md:h-5 mr-2 md:mr-3" />
                  Send Message
                </span>
              </button>
            </form>
          )}
        </div>
      </div>
    </section>
  );
};

export default Contact;