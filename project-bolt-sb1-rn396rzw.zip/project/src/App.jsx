import React, { useEffect } from 'react';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import About from './components/About';
import Skills from './components/Skills';
import Projects from './components/Projects';
import Contact from './components/Contact';
import Footer from './components/Footer';
import MouseCursor from './components/MouseCursor';
import ThemeToggle from './components/ThemeToggle';
import BackgroundAnimation from './components/BackgroundAnimation';
import { useScrollAnimations } from './hooks/useScrollAnimations';

function App() {
  useScrollAnimations();

  useEffect(() => {
    // Add custom cursor class to body
    document.body.classList.add('cursor-none');
    
    // Set dark theme by default
    document.documentElement.classList.add('dark');
    
    // Device tilt parallax effect
    const handleDeviceOrientation = (e) => {
      const tiltX = e.gamma; // left-right tilt
      const tiltY = e.beta;  // front-back tilt
      
      if (tiltX !== null && tiltY !== null) {
        const parallaxElements = document.querySelectorAll('.parallax-tilt');
        parallaxElements.forEach((el, index) => {
          const intensity = (index + 1) * 0.5;
          el.style.transform = `translate3d(${tiltX * intensity}px, ${tiltY * intensity}px, 0)`;
        });
      }
    };

    window.addEventListener('deviceorientation', handleDeviceOrientation);
    
    return () => {
      document.body.classList.remove('cursor-none');
      window.removeEventListener('deviceorientation', handleDeviceOrientation);
    };
  }, []);

  return (
    <div className="relative overflow-x-hidden bg-gray-50 dark:bg-gray-900 transition-colors duration-500">
      <BackgroundAnimation />
      <MouseCursor />
      <ThemeToggle />
      
      <Navbar />
      <Hero />
      <About />
      <Skills />
      <Projects />
      <Contact />
      <Footer />
    </div>
  );
}

export default App;